//import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class ADDPROOFSPOSTAL {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	Connection con;
	Statement stmt;
	ResultSet rs;
	private JTextField textField_3;
	private JTextField textField_4;
	
	/**
	 * Create the application.
	 */
	public ADDPROOFSPOSTAL() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		initialize();
		this.frame.setVisible(true);
	}
    void connectToDB() 
    {
		try 
		{
		 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","it19737103","vasavi");
		  stmt = con.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 926, 506);
		frame.setTitle("DRIVING SCHOOL MANAGEMENT SYSTEM");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("PERSON_ID:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(87, 50, 132, 29);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("NAME:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_1.setBounds(87, 89, 181, 32);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("AADHAR NUMBER:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_2.setBounds(87, 131, 181, 39);
		frame.getContentPane().add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setBounds(299, 43, 189, 28);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(299, 94, 189, 28);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(20);
		
		textField_2 = new JTextField();
		textField_2.setBounds(299, 137, 190, 31);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(20);
		
		/*btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton_1.setBounds(488, 395, 120, 39);
		frame.getContentPane().add(btnNewButton_1);
		*/
		JLabel lblNewLabel_3 = new JLabel("TENTH_MEMO:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_3.setBounds(87, 180, 162, 32);
		frame.getContentPane().add(lblNewLabel_3);
		
		textField_3 = new JTextField();
		textField_3.setBounds(299, 178, 189, 28);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("POSTAL_ADDRESS:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_4.setBounds(87, 229, 162, 28);
		frame.getContentPane().add(lblNewLabel_4);
		
		textField_4 = new JTextField();
		textField_4.setBounds(299, 231, 189, 29);
		frame.getContentPane().add(textField_4);
		textField_4.setColumns(20);
		/*
		JLabel lblNewLabel_5 = new JLabel("EMAIL_ID:");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_5.setBounds(103, 279, 132, 28);
		frame.getContentPane().add(lblNewLabel_5);
		
		textField_5 = new JTextField();
		textField_5.setBounds(299, 283, 189, 26);
		frame.getContentPane().add(textField_5);
		textField_5.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("ADDRESS:");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_6.setBounds(103, 331, 120, 26);
		frame.getContentPane().add(lblNewLabel_6);
		
		textField_6 = new JTextField();
		textField_6.setBounds(299, 324, 189, 32);
		frame.getContentPane().add(textField_6);
		textField_6.setColumns(10);*/
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JButton btnNewButton = new JButton("SUBMIT!");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton) {
					  	int person_id;
			            String name;
			            int aadhar_num;
			            String tenth_memo;
			            person_id = Integer.parseInt(textField.getText());
			             name = textField_1.getText();
			            aadhar_num = Integer.parseInt(textField_2.getText());
			            
			            tenth_memo = textField_3.getText();
			            String postal_address = textField_4.getText();
			            //String name = textField_1.getText();
			            //String email_id = textField_5.getText();
			            //String address = textField_6.getText();
			            
			           
			            try {
			           
			            	 PreparedStatement pstmt = con.prepareStatement("insert into id_proofs(person_id,name,aadhar_num,tenth_memo,postal_address) values (?,?,?,?,?)");
			            	        pstmt.setInt(1, person_id);
			            	        pstmt.setString(2, name);
			            	        pstmt.setInt(3, aadhar_num);
			            	        pstmt.setString(4, tenth_memo);
			            	       pstmt.setString(5, postal_address);
			            	       // pstmt.setString(6, email_id);
			            	        //pstmt.setString(7, address);
			            	        int i=pstmt.executeUpdate();  
						   
							JOptionPane.showMessageDialog(null, "\nInserted " + i + " rows successfully");
				   }
			            catch(Exception E)
			            { 
			            	JOptionPane.showMessageDialog(null, "\nCheck the details!!!!");
			            	
			            	System.out.println(E);}   
			}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton.setBounds(206, 395, 189, 39);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_2 = new JButton("CLEAR");
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton_2.setBounds(463, 397, 126, 39);
		frame.getContentPane().add(btnNewButton_2);
		
		JLabel lblNewLabel_7 = new JLabel("ADD DETAILS:");
		lblNewLabel_7.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_7.setBounds(513, 128, 389, 250);
		Image img =  new ImageIcon(this.getClass().getResource("/add-cust.png")).getImage();
		lblNewLabel_7.setIcon(new ImageIcon(img));
		lblNewLabel_7.setBounds(513, 146, 400,271);
		frame.getContentPane().add(lblNewLabel_7);
		
		/*JLabel lblNewLabel_8 = new JLabel("");
		lblNewLabel_8.setBounds(564, 101, 311, 267);
		Image img =  new ImageIcon(this.getClass().getResource("/add-cust.png")).getImage();
		lblNewLabel.setIcon(new ImageIcon(img));
		lblNewLabel.setBounds(564, 101, 311, 267);
		frame.getContentPane().add(lblNewLabel_8);
		*/
		
		//JButton btnNewButton_2 = new JButton("clear");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				  if (e.getSource() == btnNewButton_2) {
					  textField.setText("");
					  textField_1.setText("");
					  textField_2.setText("");
					  textField_3.setText("");
					  textField_4.setText("");
					  //textField_5.setText("");
					 // textField_6.setText("");
			        }
			}
		});
		
	}
}
