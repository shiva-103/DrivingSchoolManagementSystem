//import java.awt.EventQueue;
import java.awt.Image;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class EDITCUSTOMER {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	Connection con;
	Statement stmt;
	ResultSet rs;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	/**
	 * Create the application.
	 */
	public EDITCUSTOMER() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		initialize();
		this.frame.setVisible(true);
	}
	 void connectToDB() 
	    {
			try 
			{
			 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","it19737103","vasavi");
			  stmt = con.createStatement();

			} 
			catch (SQLException connectException) 
			{
			  System.out.println(connectException.getMessage());
			  System.out.println(connectException.getSQLState());
			  System.out.println(connectException.getErrorCode());
			  System.exit(1);
			}
	    }
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 854, 505);
		frame.setTitle("DRIVING SCHOOL MANAGEMENT SYSTEM");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("CUST_ID:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(125, 50, 90, 38);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("C_NAME:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_1.setBounds(125, 98, 139, 29);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("DATE_OF_JOIN:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_2.setBounds(125, 134, 130, 29);
		frame.getContentPane().add(lblNewLabel_2); 
		
		textField = new JTextField();
		textField.setBounds(268, 57, 96, 29);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(268, 102, 139, 26);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(20);
		
		textField_2 = new JTextField();
		textField_2.setBounds(268, 137, 139, 27);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(15);
		
		
		
		JLabel lblNewLabel_4 = new JLabel("LICENCE_TYPE:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_4.setBounds(125, 184, 130, 26);
		frame.getContentPane().add(lblNewLabel_4);
		
		textField_3 = new JTextField();
		textField_3.setBounds(268, 184, 139, 25);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(15);
		
		JLabel lblNewLabel_5 = new JLabel("MOBILE_NUM:");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_5.setBounds(125, 220, 130, 31);
		frame.getContentPane().add(lblNewLabel_5);
		
		textField_4 = new JTextField();
		textField_4.setBounds(268, 219, 138, 28);
		frame.getContentPane().add(textField_4);
		textField_4.setColumns(12);
		
		JLabel lblNewLabel_6 = new JLabel("EMAIL_ID:");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_6.setBounds(125, 261, 115, 26);
		frame.getContentPane().add(lblNewLabel_6);
		
		textField_5 = new JTextField();
		textField_5.setBounds(268, 260, 139, 26);
		frame.getContentPane().add(textField_5);
		textField_5.setColumns(20);
		
		JLabel lblNewLabel_7 = new JLabel("ADDRESS:");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_7.setBounds(125, 307, 115, 20);
		frame.getContentPane().add(lblNewLabel_7);
		
		textField_6 = new JTextField();
		textField_6.setBounds(268, 303, 139, 26);
		frame.getContentPane().add(textField_6);
		textField_6.setColumns(20);
		
		JLabel lblNewLabel_9= new JLabel("EDIT CUSTOMER");
		lblNewLabel_9.setFont(new Font("Monospaced", Font.BOLD, 25));
		lblNewLabel_9.setBounds(474, 166, 231, 29);
		frame.getContentPane().add(lblNewLabel_9);
		JButton btnNewButton = new JButton("MODIFY!");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton) {
					try {
						int cust_id;
			           String c_name;
			            String date_of_join;
			            cust_id = Integer.parseInt(textField.getText());
			           c_name=textField_1.getText();
			            date_of_join=textField_2.getText();
			            String licence_type = textField_3.getText();
			            int mobile_num = Integer.parseInt(textField_4.getText());
			            String email_id = textField_5.getText();
			            String address = textField_6.getText();
			            
			                
			            	 PreparedStatement pstmt = con.prepareStatement("update customer_details set c_name=(?),date_of_join=(?),licence_type=(?),mobile_num=(?),email_id=(?),address=(?) where cust_id=(?)");
			            	 
		            	        pstmt.setString(1, c_name);
		            	        pstmt.setString(2, date_of_join);
		            	        pstmt.setString(3, licence_type);
		            	        pstmt.setInt(4, mobile_num);
		            	        pstmt.setString(5, email_id);
		            	        pstmt.setString(6, address);
		            	        pstmt.setInt(7, cust_id);
		            	       //pstmt.setString(2, c_name);
		            	        
		            	        int i=pstmt.executeUpdate();   
						    
							JOptionPane.showMessageDialog(null, "\nUpdated " + i + " rows successfully!");
				   }
			            catch(Exception E)
			            { 
			            	JOptionPane.showMessageDialog(null, "Check the details you have entered!!!!");
			            	System.out.println(E);
			            }  
			}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton.setBounds(160, 356, 115, 38);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("GET HELP");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton_1) {	
				JOptionPane.showMessageDialog(null, "You can get info through already existing columns in VIEWCUSTOMERS!!");
				}
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_1.setBounds(342, 356, 120, 38);
		frame.getContentPane().add(btnNewButton_1);
		
		JTextArea txtrMandotory = new JTextArea();
		txtrMandotory.setBackground(new Color(255, 255, 255));
		txtrMandotory.setFont(new Font("Monospaced", Font.BOLD, 17));
		txtrMandotory.setText("CUST_ID is Mandotory!");
		txtrMandotory.setBounds(427, 55, 205, 29);
		frame.getContentPane().add(txtrMandotory);
		
		JLabel lblNewLabel_8 = new JLabel("");
		lblNewLabel_8.setBounds(508, 154, 285, 250);
		Image img =  new ImageIcon(this.getClass().getResource("/Edit-cust.png")).getImage();
		lblNewLabel_8.setIcon(new ImageIcon(img));
		lblNewLabel_8.setBounds(513, 146, 400,271);
		frame.getContentPane().add(lblNewLabel_8);
		
		
	}
}
