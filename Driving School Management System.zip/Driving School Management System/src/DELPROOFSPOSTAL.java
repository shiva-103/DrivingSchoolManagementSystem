//import java.awt.EventQueue;
import javax.swing.JFrame;
//import javax.swing.JTextArea;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
//import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class DELPROOFSPOSTAL {
				private JFrame frame;
				private JTextField textField;
				//private JTextField textField_1;
				//private JTextField textField_2;
				Connection con;
				Statement stmt;
				ResultSet rs;
				//private JTextField textField_3;
				/**
				 * Create the application.
				 */
public DELPROOFSPOSTAL() {
					try 
					{
						Class.forName("oracle.jdbc.driver.OracleDriver");
					} 
					catch (Exception e) 
					{
						System.err.println("Unable to find and load driver");
						System.exit(1);
					}
					connectToDB();
					initialize();
					this.frame.setVisible(true);
				}
void connectToDB() 
				{
						try 
						{
						 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","it19737103","vasavi");
						  stmt = con.createStatement();

						} 
						catch (SQLException connectException) 
						{
						  System.out.println(connectException.getMessage());
						  System.out.println(connectException.getSQLState());
						  System.out.println(connectException.getErrorCode());
						  System.exit(1);
						}
				 }
				/**
				 * Initialize the contents of the frame.
				 */
private void initialize() {
					frame = new JFrame();
					frame.setBounds(100, 100, 854, 505);
					frame.setTitle("DRIVING SCHOOL MANAGEMENT SYSTEM");
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					frame.getContentPane().setLayout(null);
				
					JLabel lblNewLabel = new JLabel("AADHAR_NUM:");
					lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
					lblNewLabel.setBounds(124, 216, 139, 29);
					frame.getContentPane().add(lblNewLabel);
					
					textField = new JTextField();
					textField.setBounds(272, 218, 96, 29);
					frame.getContentPane().add(textField);
					textField.setColumns(20);
					
					
					JButton btnNewButton = new JButton("DELETE");
					btnNewButton.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							
							if (e.getSource() == btnNewButton) {
								try {
								  int aadhar_num;
						           
						            aadhar_num=Integer.parseInt(textField.getText());   
						            	
						               
						            	 PreparedStatement pstmt = con.prepareStatement("delete from id_proofs where aadhar_num=(?)");
						            	        pstmt.setInt(1, aadhar_num);        
						            	        int i=pstmt.executeUpdate();
										JOptionPane.showMessageDialog(null, "\nDeleted " + i + " rows successfully");
						          }
						               
						            catch(Exception E)
						            { 
						            	JOptionPane.showMessageDialog(null, "Wrong Entry!!!");
						            	System.out.println(E);
						            }  
						}
							
							
							
						}
							
					});
					btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
					btnNewButton.setBounds(160, 356, 104, 38);
					frame.getContentPane().add(btnNewButton);
					
					JButton btnNewButton_1 = new JButton("GET HELP");
					btnNewButton_1.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							if (e.getSource() == btnNewButton_1) {	
							JOptionPane.showMessageDialog(null, "You can refer existing columns in VIEWPROOFSPOSTAL!!!");
							}
						}
					});
					btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
					btnNewButton_1.setBounds(342, 356, 104, 38);
					frame.getContentPane().add(btnNewButton_1);
					
					
					JLabel lblNewLabel_3 = new JLabel("DELETE PROOFSPOSTAL RECORD");
					lblNewLabel_3.setFont(new Font("Monospaced", Font.BOLD, 27));
					lblNewLabel_3.setBounds(168, 37, 399, 47);
					frame.getContentPane().add(lblNewLabel_3);
					
					JLabel lblNewLabel_1 = new JLabel("");
					lblNewLabel_1.setBounds(458, 99, 356, 295);
					Image img =  new ImageIcon(this.getClass().getResource("/Delete-icon.png")).getImage();
					lblNewLabel_1.setIcon(new ImageIcon(img));
					lblNewLabel_1.setBounds(458,99,356,295);
					frame.getContentPane().add(lblNewLabel_1);
					
			
				}
			}
