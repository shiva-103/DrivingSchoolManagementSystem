import java.sql.*;


public class drive {
		public static void main(String[] args) throws Exception
		{
			String url= "";
			String uname= "shiva";
			String pass = "shiva";
			Class.forName("com.mysql.jdbc.Driver");	
			Connection con = DriverManager.getConnection(url,uname,pass);
			
		}
}
